void f (int *a)
{
    (*a)++;
}

int main ()
{
    int x = 10;

    f(&x);
}
